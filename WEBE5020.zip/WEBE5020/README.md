# Mampho Tuck Shop Website

 project with five linked HTML pages.

## Pages
- `index.html` - homepage
- `about.html` - organisation overview, mission and vision
- `products.html` - product categories and sample prices
- `enquiry.html` - demo enquiry form
- `contact.html` - sample contact information

## Folder structure
- `assets/css/style.css` - shared responsive styling
- `assets/js/main.js` - footer year and demo form behaviour
- `assets/images/` - original SVG illustrations used by the website

## How to run
Open `index.html` in a browser. No server is required.

## Notes
All business details, contact information, prices and illustrations are fictional and created for educational demonstration. Replace them with approved real information if the project is used for a real organisation.
